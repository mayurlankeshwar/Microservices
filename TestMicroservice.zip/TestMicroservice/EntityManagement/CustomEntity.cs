﻿using System;

namespace TestMicroservice.EntityManagement
{
    public class CustomEntity
    {
        public Guid EntityId { get; set; }
        public string EntityName { get; set; }
    }
}
